export default function Home() {
  return (
    <div>
      <h1>Gameverse</h1>
    </div>
  );
}
